extends Control

func _ready():
		pass
		
func _on_button_pressed():
	print("MÁGICA FUNCIONOU!")
	$Label.text = "1"
					
