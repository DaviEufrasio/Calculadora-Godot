extends Control
var num1 : float = 0.0
var operador = ""
func _ready():
	pass
func _on_botao_1_pressed():
	if $Label.text == "0":
		$Label.text = "1" # Se só tiver zero, substitui pelo 1
	else:
		$Label.text += "1" # Se já tiver outros números, vai juntando!
func _on_botao_2_pressed():
	if $Label.text == "0":
		$Label.text = "2" # Se só tiver zero, substitui pelo 1
	else:
		$Label.text += "2" # Se já tiver outros números, vai juntando!
func _on_botao_3_pressed():
	if $Label.text == "0":
		$Label.text = "3" # Se só tiver zero, substitui pelo 1
	else:
		$Label.text += "3" # Se já tiver outros números, vai juntando!
func _on_botao_4_pressed():
		if $Label.text == "0":
			$Label.text = "4" # Se só tiver zero, substitui pelo 1
		else:
			$Label.text += "4" # Se já tiver outros números, vai juntando!
func _on_botao_5_pressed():
	if $Label.text == "0":
		$Label.text = "5"
	else:
		$Label.text += "5"
func _on_botao_6_pressed():
	if $Label.text == "0":
		$Label.text = "6"
	else:
		$Label.text += "6"
func _on_botao_7_pressed():
	if $Label.text == "0":
		$Label.text = "7" # Se só tiver zero, substitui pelo 1
	else:
		$Label.text += "7" # Se já tiver outros números, vai juntando!
func _on_botao_8_pressed():
	if $Label.text == "0":
		$Label.text = "8" # Se só tiver zero, substitui pelo 1
	else:
		$Label.text += "8" # Se já tiver outros números, vai juntando!
func _on_botao_9_pressed():
	if $Label.text == "0":
		$Label.text = "9"
	else:
		$Label.text += "9"
func _on_botao_0_pressed():
	if $Label.text == "0":
		return
	elif $Label.text == "":
		$Label.text = "0"
	else:
		$Label.text += "0"
																

func _on_botao_virgula_pressed():
	if not "." in $Label.text:
		if $Label.text == "" or $Label.text == "0":
			$Label.text = "0."
		else:
			$Label.text += "."
func _on_botao_adicionar_pressed():
	num1 = float($Label.text) 
	operador = "+" 
	$Label.text = "" 
									
func _on_botao_subtrair_pressed():
	num1 = float($Label.text)
	operador = "-"
	$Label.text = ""
func _on_botao_multiplicar_pressed():
	num1 = float($Label.text)
	operador = "*"
	$Label.text = ""
func _on_botao_dividir_pressed():
	num1 = float($Label.text)
	operador = "/"
	$Label.text = ""
func _on_botao_potencia_pressed():
	num1 = float($Label.text)
	operador = "**"
	$Label.text = ""
func _on_botao_limpar_pressed():
	$Label.text = "0"
	num1 = 0.0
	operador = ""
																				
func _on_botao_igual_pressed():
	var num2 = float($Label.text)
	var resultado = 0.0
	
	if operador == "+":
		resultado = num1 + num2
	elif operador == "-":
		resultado= num1 - num2 
	elif operador == "*":
		resultado= num1 * num2 
	elif operador == "**":
		resultado = num1 ** num2 
	elif operador == "/":
		if num2 != 0:
			resultado = num1 / num2 
		else:
			$Label.text = "Erro"
			return
	var texto_final = str(resultado)
	if texto_final.ends_with(".0"):
		texto_final = texto_final.left(-2) # Remove os 2 últimos caracteres
		$Label.text = texto_final
	pass # Replace wih function body.
																																																																																												
